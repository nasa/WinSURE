#if !defined(_ZZ_q_macvars_DEFINED)
#define _ZZ_q_macvars_DEFINED
/*===========================================================================*/
#include "lib_def.h"
#include "prstypes.h"
EXKW token_info_type *function_body_storage;
EXKW macro_expansion_info_type *macro_stack;
/**/
EXKW Memix function_body_count;
EXKW Stacktop macro_stack_top;
/*===========================================================================*/
#endif
