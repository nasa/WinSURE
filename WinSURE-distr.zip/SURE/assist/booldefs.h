#if !defined(_ZZ_q_booldefs_DEFINED)
#define _ZZ_q_booldefs_DEFINED
/*===========================================================================*/
typedef unsigned char Boolean;
#define FALSE ((Boolean) 0)
#define TRUE ((Boolean) 1)
/*===========================================================================*/
#endif
