#define IDM_TEXT      100
#define IDM_BITMAP    101
#define IDM_EXIT      102
#define IDM_HELP      103
#define IDM_WINDOW    104
#define IDM_INPUTFILE 105
#define IDM_RERUN     106
#define IDM_LISTMOD   107
#define IDM_LISTING   108
#define IDM_DIALOG1   109

#define IDD_EB1       200
#define IDD_EB2       201
#define IDD_UD1       202
#define IDD_UD2       202

#define IDD_TEXT1     210
#define IDD_TEXT2     211




#define ID_EB1       110

#define ID_CB1       111
#define ID_CB2       112
#define ID_CB3       113
#define ID_CT1       114
#define ID_CT2       115
#define ID_CT3       116
#define ID_CT4       117

#define ID_LB1       118
