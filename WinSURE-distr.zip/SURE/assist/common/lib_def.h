/*
    To be included as the first local include of all library files.
    For example:

                  #include "lib_def.h"
                  #include "....."
                  ....
*/
#if !defined(EXKW_DEFINED)
#define EXKW_DEFINED
#define EXKW extern
#endif
