#if !defined(_ZZ_q_pass_DEFINED)
#define _ZZ_q_pass_DEFINED

#include "cm_types.h"

extern char encoded_state_string[];
extern reserved_word_lookup_type reserved_word_lookup_table[];
extern char tempnam_buffer[];

extern char encoded_aux_val[];
extern char enk_5_or_more_str[];

#endif
