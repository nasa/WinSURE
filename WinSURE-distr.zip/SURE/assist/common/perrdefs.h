#if !defined(_ZZ_q_perrdefs_DEFINED)
#define _ZZ_q_perrdefs_DEFINED

#define E_MOD0 23
#define E_CYC0 23
#define E_DVD0 23
#define E_RDVD0 23
#define E_NEGROOT 31
#define E_LNOFNEG 31
#define E_NEGTOREAL 31
#define E_EXPOVF 32
#define E_INTEGEROVF 32001
#define E_REALOVF 32002
#define E_NEGVALUE 32003
#define E_KVSN 32004

#endif
