/*
    To be included as the first local include of the main program.
    For example:

                  #include "main_def.h"
                  #include "....."
                  ....
                  int main(int argc,char **argv)
                  {
                      ....
                  }
*/
#if !defined(EXKW_DEFINED)
#define EXKW_DEFINED
#define EXKW
#define STORAGE
#endif
