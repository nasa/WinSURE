#if !defined(_ZZ_q_fact_ext_DEFINED)
#define _ZZ_q_ZZ_q_fact_ext_DEFINED

#include "cm_sys.h"

extern int_type ifact(int_type);
extern int_type icomb(int_type,int_type);
extern int_type iperm(int_type,int_type);

#endif
