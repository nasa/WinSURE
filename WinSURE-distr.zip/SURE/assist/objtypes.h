#if !defined(_ZZ_q_objtypes_DEFINED)
#define _ZZ_q_objtypes_DEFINED
/*===========================================================================*/
#include "objdefs.h"
#include "cm_types.h"
typedef unsigned_255_type object_table_type;
/*===========================================================================*/
#endif
