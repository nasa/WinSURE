#
rm *.o common/*.o
cd test
rm *.aobj *.alog *.alg *.aob
cd .. 
cd test2
rm *.aobj *.alog *.alg *.aob
cd .. 
cd test3
rm *.aobj *.alog *.alg *.aob
cd .. 
