#if !defined(_ZZ_q_uprs_ext_DEFINED)
#define _ZZ_q_uprs_ext_DEFINED
/*===========================================================================*/
extern void show_prs_sizes_on_both(void);
/*===========================================================================*/
#endif
