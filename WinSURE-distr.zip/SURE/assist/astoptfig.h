#if !defined(_ZZ_q_astoptfig_DEFINED)
#define _ZZ_q_astoptfig_DEFINED
/*===========================================================================*/

#define OPTIONS_CONFIG_FILE ".assist_options"


/*===========================================================================*/
#endif
