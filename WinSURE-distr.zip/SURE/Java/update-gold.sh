cp ../gold/runs.out ../gold/old
cp mold/runs.out ../gold
echo "jSURE gold updated!"

